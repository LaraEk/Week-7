// ----- Here are all the ways that moment.js DID NOT work: ----- //

// var now = moment();
// console.log("this is now" + now);
//var x =  moment.duration(now); 
//var thisisnow = x.hours() + x.minutes();
// var thisisnow = moment().startOf('day').add(now, 'minutes').format('hh:mm A');
//console.log("BEEP BEEP The current time is:" + thisisnow);
